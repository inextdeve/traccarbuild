import os
import cv2
from ultralytics import YOLO
import numpy as np
try:
    import easyocr
except:
    os.system('pip install easyocr')
import csv
import argparse
import torch


def remove_quotes(string):
    string = string.replace('"', '')
    string = string.replace("'", '')
    return string


# Parse command-line arguments
parser = argparse.ArgumentParser(description='YOLO Object Detection')
parser.add_argument('--weights', type=str, default='best.pt', help='path to YOLO weights file')
parser.add_argument('--video', type=str, default='dashcam_damage.mp4', help='path to video file')
args = parser.parse_args()

model = YOLO(args.weights)

if torch.cuda.is_available():
    reader = easyocr.Reader(['en'], gpu=True)
else:
    reader = easyocr.Reader(['en'], gpu=False)

video_path = args.video
video_out_path = os.path.join('.', 'out.mp4')

cap = cv2.VideoCapture(video_path)
ret, frame = cap.read()

cap_out = cv2.VideoWriter(video_out_path, cv2.VideoWriter_fourcc(*'MP4V'), cap.get(cv2.CAP_PROP_FPS),
                          (frame.shape[1], frame.shape[0]))

csvfile = open('output.csv', 'w', newline='')
writer = csv.writer(csvfile)
writer.writerow(['damaged_positions'])

rows = []
damage_counter = 0

while True:
    ret, frame = cap.read()

    if not ret:
        break

    results = model(frame, verbose=False, conf=0.5, imgsz=640)
    frame_crop = frame.copy()[640:, 222:500]

    classes = []
    for result in results:
        for r in result.boxes.data.tolist():
            x1, y1, x2, y2, score, class_id = r
            x1 = int(x1)
            x2 = int(x2)
            y1 = int(y1)
            y2 = int(y2)
            class_id = int(class_id)
            if class_id == 0:
                cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 0, 255), 3)
                classes.append(class_id)
            else:
                cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 3)

    if len(classes) > 0:
        position_text = reader.readtext(frame_crop)[0][1]
        position_text = remove_quotes(str(position_text))
        damage_counter += 1
        if not (position_text in rows) and damage_counter > 30:
            rows.append(str(position_text))
            writer.writerow([position_text])
    else:
        damage_counter = 0

    cap_out.write(frame)
    cv2.imshow('frame', frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cap_out.release()
cv2.destroyAllWindows()
