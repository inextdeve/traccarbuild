<?php 
$auto = "AuTo";
include ("header.php");
if($_GET['n']){$n=$_GET['n'];}else{$n=1;}

if(isset($_GET['date_t']) and isset($_GET['date_f']) and isset($_GET['time_f']) ){
	$time_f = $_GET['time_f'];
	$time_t = $_GET['time_t'];
	$date_f =  $_GET['date_f'];
	$date_t =  $_GET['date_t'];
	
	$timedate_f = $date_f." ".$time_f;
	$timedate_t = $date_t." ".$time_t;
	

	$timedate = "timedate";	

}else{
$time_f = $show_site['start_day'];	
$time_t = $show_site['end_day'];	
$date_f =  date("Y-m-d");
$date_t =  date("Y-m-d");

	$timedate_f = $date_f." ".$time_f;
	$timedate_t = $date_t." ".$time_t;
	$timedate = null;
	
}


?>
<div id="div-list">
<div id="loading" class="loadingpg" ><span class="loader"></span></div>
</div>
<div class='pop_wind show-det-div' >
<div class='close'>×</div>
<div id="status_data" >
<div id="loading" ><span class="loader"></span></div>
</div>
</div>
<script>
$(document).ready(function(){
	 $.get( "send.php?n=<?php  echo $n; ?>&timedate=<?php echo $timedate;  ?>&time_f=<?php  echo $time_f; ?>&time_t=<?php  echo $time_t; ?>&date_f=<?php  echo $date_f; ?>&date_t=<?php  echo $date_t; ?>", function( data ) {
				$("#div-list").html(data);
			});		
 var setiv = setInterval(function(){
	 $.get( "send.php?n=<?php  echo $n; ?>&timedate=<?php echo $timedate;  ?>&time_f=<?php  echo $time_f; ?>&time_t=<?php  echo $time_t; ?>&date_f=<?php  echo $date_f; ?>&date_t=<?php  echo $date_t; ?>", function( data ) {
				$("#div-list").html(data);
			});	
    },30000);	
	
});
</script>

</div>
</div>

</body>
</html>
<?php 
ob_end_flush();
?>