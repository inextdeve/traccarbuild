<?php 
include "../config.php";

if(isset($_GET['infoid']) and isset($_GET['desc'])){
			$q_info = mysqli_query($con,"select * from tc_geofences 
					inner join tcn_routs on tc_geofences.routid = tcn_routs.id 
					inner join tcn_centers on tc_geofences.centerid = tcn_centers.id 
					inner join tcn_bin_type on tc_geofences.bintypeid = tcn_bin_type.id
					where tc_geofences.type_bins = '0' and tc_geofences.id ='".$_GET['infoid']."' " );
			 $show_info = mysqli_fetch_array($q_info);

	
		$q = mysqli_query($con,"select serv_time from tcn_poi_schedule where geoid = '".$_GET['infoid']."' order by serv_time desc limit 1");
		$show = mysqli_fetch_array($q);
			
		$qq = mysqli_query($con,"select * from tcn_routs inner join tc_drivers on tcn_routs.driverid = tc_drivers.id  where tcn_routs.id = '".$show_info['routid']."' limit 1");
		$sh = mysqli_fetch_array($qq);

			echo "<p>".$langs['tb_route'].' : '.$show_info['rout_code'].'</p><p>'.$langs['tb_type'].' : '.$langs_title[$show_info['bintype']].'</p><p> '.$langs['container'].' :'.$_GET['desc'].'</p><p> '.$langs['tb_last_time_empty'].' :'.date_css($show['serv_time']).'</p><p> '.$langs['tb_status'].' : <b> '.$langs['status_non_empty'].' </b></p>' ;
			$area = explode(",",map($show_info['area']));

		echo "<a target='_blank' class='openg' href='https://www.google.com/maps/place/".$area[0].",".$area[1]."'><i class='fa-solid fa-map-location-dot'></i></a>";
		echo "<button  class='selbin btn_send pgun' idus='".$_GET['idus']."' selbin='".$_GET['infoid']."' > ".$langs['sel_bin']." </button>";
			

}
?>
<script>
 $(".selbin").click(function(){
	let atr = $(this).attr("selbin");
	let idus = $(this).attr("idus");
	
	let th = $(this);
	th.html("..");	
	$.get( "selbin.php?id="+atr+"&user="+idus+"", function( data ) {
	th.html(data);
});
});
  
</script>
