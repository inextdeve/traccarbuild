<?php 
include("../config.php");

session_destroy();
    unset($_COOKIE['binsServ_activecode']);
    unset($_COOKIE['binsServ_login']);
    unset($_COOKIE['binsServ_phone']);
    unset($_COOKIE['binsServ_username']);

	setcookie(''.md5("binsServ_activecode").'','', time() - 3600, "/");
	setcookie(''.md5("binsServ_login").'','', time() - 3600, "/"); 
	setcookie(''.md5("binsServ_phone").'','', time() - 3600, "/"); 	
	setcookie(''.md5("binsServ_username").'','', time() - 3600, "/"); 
	
header("Location: index.php");
?>