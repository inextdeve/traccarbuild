<?php 
  include    "../tel/vendor/autoload.php";
  use telesign\sdk\messaging\MessagingClient;
include ("../config.php");
	$time_f = $_GET['time_f'];
	$time_t = $_GET['time_t'];
	$date_f =  $_GET['date_f'];
	$date_t =  $_GET['date_t'];
	
	$timedate_f = $date_f." ".$time_f;
	$timedate_t = $date_t." ".$time_t;
	
if($_GET['timedate'] != null){
 $date_string = "and binsServ_msgs.timedate  between  '".$timedate_f."'  and  '".$timedate_t."' ";
}	


$arraytoken = array(
28=>'x6lf1axmx0kmiimb',
29=>'x6lf1axmx0kmiimb',
30=>'x6lf1axmx0kmiimb',
96=>'x6lf1axmx0kmiimb',
97=>'x6lf1axmx0kmiimb',
98=>'x6lf1axmx0kmiimb',
99=>'x6lf1axmx0kmiimb',
100=>'x6lf1axmx0kmiimb',
101=>'x6lf1axmx0kmiimb',
102=>'x6lf1axmx0kmiimb',
103=>'x6lf1axmx0kmiimb',
104=>'x6lf1axmx0kmiimb',
105=>'x6lf1axmx0kmiimb',
106=>'x6lf1axmx0kmiimb',
107=>'x6lf1axmx0kmiimb',
108=>'x6lf1axmx0kmiimb',
109=>'x6lf1axmx0kmiimb',
110=>'x6lf1axmx0kmiimb',
111=>'x6lf1axmx0kmiimb',
112=>'x6lf1axmx0kmiimb',
113=>'x6lf1axmx0kmiimb');

$time_f_now = $show_site['start_day'];	
$time_t_now  = $show_site['end_day'];	
$date_f_now  =  date("Y-m-d");
$date_t_now  =  date("Y-m-d");

	$timedate_f_now  = $date_f_now ." ".$time_f_now ;
	$timedate_t_now  = $date_t_now ." ".$time_t_now ;
	
	
$q = mysqli_query($con,"select DISTINCT tcn_routs.id as r_id,tc_devices.id as devid from  tc_events 
				inner join tc_devices on tc_events.deviceid = tc_devices.id
				inner join tcn_routs on tc_devices.id = tcn_routs.deviceid
				where (tc_events.type = 'geofenceExit' or 'ignitionOn')   AND
				tc_events.eventtime  between  '".$timedate_f_now."' and '".$timedate_t_now."' ");
	while($show = mysqli_fetch_array($q)){


		$qq = mysqli_query($con,"select *,binsServ.id as id_user from tc_geofences inner join binsServ on tc_geofences.id=binsServ.idbin where tc_geofences.routid = '".$show['r_id']."' ");
		while($sh = mysqli_fetch_array($qq)){
			$qqq = mysqli_query($con,"select * from binsServ_msgs where binsServ_msgs.idusername='".$sh['id_user']."' and binsServ_msgs.date = '".date("Y-m-d")."' ");
			if(mysqli_num_rows($qqq) == 0){

/********************************/				
$text = " مرحبا, ".$sh['username'];
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.ultramsg.com/instance27714/messages/chat",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "token=".$arraytoken[$show['r_id']]."&to=+".$sh['phone']."&body=".$text."&priority=1&referenceId=",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));


 $response = json_decode(curl_exec($curl),true);

$err = curl_error($curl);
curl_close($curl);

if ($err) {
 // echo "cURL Error #:" . $err;
} else {
  if($response['sent'] == true){
	$q_ins = mysqli_query($con,"insert into binsServ_msgs (`idusername`,`phone`,`idbin`,`timedate`,`date`) 
	values('".$sh['id_user']."','".$sh['phone']."','".$sh['idbin']."','".date("Y-m-d H:i:s")."','".date("Y-m-d")."')");
echo mysqli_error($con);
  }else{

  }
}

   /**********************************************/
   
   
			}
		}
	}
	
	
?>

<div id="date-form">
<form action="" method='get'>
<label><?php echo $langs['Date_from']; ?></label>
<input name="time_f" step="1" type="time" value= "<?php if(!isset($_GET['time_f'])){ echo $show_site['start_day'];}else{ echo $_GET['time_f']; } ?>">
<input id="date_f" placeholder="from" max="<?php echo date("20y-m-d"); ?>" name='date_f' value= "<?php if(!isset($_GET['date_f'])){ echo date("20y-m-d");}else{ echo $_GET['date_f']; } ?>" type="date" /> 
<label><?php echo $langs['Date_to']; ?></label>
<input name="time_t" step="1" type="time" value= "<?php if(!isset($_GET['time_t'])){ echo $show_site['end_day'];}else{ echo $_GET['time_t']; } ?>">
<input id="date_t" placeholder="to" max="<?php echo date("20y-m-d"); ?>" name='date_t' value= "<?php if(!isset($_GET['date_t'])){ echo date("20y-m-d");}else{ echo $_GET['date_t']; } ?>" type="date" /> 
<button data-html2canvas-ignore="true" class="sh-load" type="submit"> <?php echo $langs['btn_show']; ?>  </button>
</form>
</div>


<table class="table-g" data-tablesaw-mode="columntoggle">
<thead>
<tr class="headtable">
<th>#</th>
<th><?php echo $langs['inp_user']; ?></th>
<th><?php echo $langs['inp_phone']; ?></th>
<th><?php echo $langs['id_container']; ?></th>
<th><?php echo $langs['tb_route']; ?></th>
<th><?php echo $langs['tb_id_eqipment']; ?></th>
<th><?php echo $langs['tb_date']; ?></th>
<th data-html2canvas-ignore='true'  > <i class='fa-solid fa-chart-pie'></i> </th>
</tr>
</thead>
<tbody>
<?php	
        $total_reg = 40; 
		if(isset($_GET['n'])){		
			$n=$_GET['n'];
		}else {$n=1;}
        $begin = $n - 1;
        $begin = $begin * $total_reg;

	$count = ($begin +1);
	
$Q= mysqli_query($con,"select *,tc_devices.name as devc_name,binsServ_msgs.phone as us_phone from binsServ_msgs 
inner join binsServ on binsServ_msgs.idusername = binsServ.id
inner join tc_geofences on binsServ_msgs.idbin = tc_geofences.id 
inner join tcn_routs on tc_geofences.routid  = tcn_routs.id 
inner join tc_devices on tcn_routs.deviceid = tc_devices.id 
where binsServ_msgs.idusername = binsServ.id  $date_string
limit $begin,$total_reg ");

while($show = mysqli_fetch_array($Q)){
	echo "<tr><td>".($count ++)."</td> <td>".$show['username']."</td> <td>".$show['us_phone']."</td> <td>".$show['description']."</td>  
	<td>".$show['rout_code']."</td>  <td>".$show['devc_name']."</td> <td>".date_css($show['timedate'])."</td> <td>
	<button class='btn-show show-det' id-bin='".$show['idbin']."' id-us='".$show['idusername']."' timedate_f='".$timedate_f."' timedate_t='".$timedate_t."' >".$langs['details']."</button> </td></tr>";
}
	

?>
</tbody>
</table>
<div data-html2canvas-ignore='true' id="bar_number">

<?php 

$Q = mysqli_query($con,"select *,tc_devices.name as devc_name,binsServ_msgs.phone as us_phone from binsServ_msgs 
inner join binsServ on binsServ_msgs.idusername = binsServ.id
inner join tc_geofences on binsServ_msgs.idbin = tc_geofences.id 
inner join tcn_routs on tc_geofences.routid  = tcn_routs.id 
inner join tc_devices on tcn_routs.deviceid = tc_devices.id 
where binsServ_msgs.idusername = binsServ.id  $date_string
");
 $allres = mysqli_num_rows($Q);
 $total_pages = ceil($allres / $total_reg);
for($i = 1;$i <= $total_pages;$i++){
    if($i == $n){
        echo '<a class="num active" href="#">'.$i.'</a>';
    }else{
		if($_GET['timedate'] == null){
			echo '<a class="num sh-load" href="?n='.$i.'">'.$i.'</a>';
		}else{
		echo '<a class="num sh-load" href="?n='.$i.'&time_f='.$_GET['time_f'].'&date_f='.$_GET['date_f'].'&time_t='.$_GET['time_t'].'&date_t='.$_GET['date_t'].'">'.$i.'</a>';
		}
	}
}
?>
</div>


<script>
$(document).ready(function(){

$(".show-det").click(function(){
	
	let idstatusdet = $(this).attr("id-bin");
	let idusdet = $(this).attr("id-us");
	let timedatef = $(this).attr("timedate_f");
	let timedatet = $(this).attr("timedate_t");
	$(".show-det-div #status_data").html('<div id="loading" ><span class="loader"></span></div>');
	$(".show-det-div").show();	
	$.get("det-bins.php?id="+idstatusdet+"&iduser="+idusdet+"&timedate_f="+timedatef+"&timedate_t="+timedatet+"",function(data){
	$(".show-det-div #status_data").html(data);
	});

$(".close").click(function(){
	$(this).parent(".show-det-div").hide();
	
});	

});
});
</script>
<script>
$(".table-g .headtable th").attr("data-tablesaw-priority","1");	
for(var i=0;i<=document.getElementsByClassName('table-g').length-1;i++){
	   new Tablesort(document.getElementsByClassName('table-g')[i]);
}
</script>