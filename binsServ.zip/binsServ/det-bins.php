<?php 
include "../config.php";
?>

<?php 
$timedate_f = $_GET['timedate_f'];
$timedate_t = $_GET['timedate_t'];


$q_info = mysqli_query($con,"select *,tc_geofences.id as idg,tc_drivers.name as drv_name,tc_drivers.phone as drv_phone from tc_geofences 
				left join tcn_poi_schedule on tc_geofences.id=tcn_poi_schedule.geoid and  tcn_poi_schedule.serv_time   between  '".$timedate_f."' and '".$timedate_t."'				
					inner join tcn_routs on tc_geofences.routid = tcn_routs.id 
					inner join binsServ on tc_geofences.id = binsServ.idbin and  binsServ.id = '".$_GET['iduser']."'
					inner join tc_devices on tcn_routs.deviceid = tc_devices.id 
					inner join  tc_drivers on tcn_routs.driverid = tc_drivers.id 
					where  tc_geofences.id ='".$_GET['id']."' " );
$show_info = mysqli_fetch_array($q_info);
	$myLocation = explode(",,",map($show_info['location']));

 $locationLat = $myLocation[0];
 $locationLon = $myLocation[1];	
 
 $area = explode(",",map($show_info['area']));

if($show_info['geoid']){
	$arr[] ='["<p> '.$langs['tb_route'].' : ' .$show_info['rout_code'].'</p><p> '.$langs['tb_type'].' : ' .$langs_title[$show_info['bintype']].'</p><p> '.$langs['container'].' : '.$show_info['description'].'</p><p> '.$langs['tb_last_time_empty'].' : '.date_css($show_info['serv_time']).'</p><p>'.$langs['tb_status'].' : <strong> '.$langs['status_empty'].' </strong> </p> <a target=\'_blank\' class=\'openg\' href=\'https://www.google.com/maps/place/'.$area[0].','.$area[1].'\'><i class=\'fa-solid fa-map-location-dot\'></i></a>   </hr />",' .map($show_info['area']).']';	
}else{
	$arri[] ='["type='.$langs['tb_route'].' : '.$show_info['rout_code'].'&infoid=' .$show_info['idg'].'&desc='.$show_info['description'].'",' .map($show_info['area']).']';
}

if(!isset($arr)){
	$arr[] = '["NAN",0,0]';

} 
if(!isset($arri)){
	$arri[] = '["NAN",0,0]';
 
} 

?>
<div id='content-det-em'>
<table>
<?php 
echo "
<tr><td>".$langs['id_container']."</td><td>".$show_info['description']."</td></tr>
<tr><td>".$langs['driver_name']."</td><td>".$show_info['drv_name']."</td></tr>
<tr><td>".$langs['phone_driver']."</td><td>".$show_info['drv_phone']."</td></tr>
"; 

 ?>
</table>
<div id="map" style="width: 96%; height: 480px; border: 2px solid #568f31;"></div>

<script>

 


var locations = [
<?php echo implode(",",$arr); ?>

];

var locationsi = [
<?php echo implode(",",$arri); ?>

];




var startIcon = new L.Icon({
  iconUrl: '../themes/images/icons8-home-page-96.png',
  shadowUrl: '../themes/images/marker-shadow.png',
  iconSize: [35, 35],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

var binsIcon_sel = new L.Icon({
  iconUrl: '../themes/images/recycle-bin-done.png',
  shadowUrl: '../themes/images/marker-shadow.png',
  iconSize: [33, 33],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});



	var MyLoc = L.layerGroup();
		Mymarker = new L.marker([<?php echo $locationLat.", ".$locationLon; ?>],{icon:startIcon})
		.bindPopup(" <i class='fa-solid fa-house'></i> Home")
		.addTo(MyLoc);


	var done_h = L.layerGroup();
	for (var i = 0; i < locations.length; i++) {
		marker = new L.marker([locations[i][1], locations[i][2]],{icon: binsIcon_sel})
		.bindPopup(locations[i][0])
		.addTo(done_h);
}	


	var undone = L.layerGroup();
	for (var i = 0; i < locationsi.length; i++) {
		markeri = new L.marker([locationsi[i][1], locationsi[i][2]],{icon: binsIcon_sel});
		markeri.bindPopup("loading...");
		let urlu = locationsi[i][0];
		markeri.on('click',function(e){
			var popup = e.target.getPopup();
			$.get( "unbin.php?"+urlu+"&idus="+<?php echo $_GET['iduser']; ?>+"", function( data ) {
						popup.setContent( data );
						popup.update();		
					
 $(".selbin").hide();		
			});	
			
		});
		markeri.addTo(undone);
}


	var mbAttr = '&copy; <a href="">almajal</a>';

 
	var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="#">almajal</a>'
	});
	
	googleSat = L.tileLayer('http://{s}.google.com/vt?lyrs=s&x={x}&y={y}&z={z}',{
    maxZoom: 20,
    subdomains:['mt0','mt1','mt2','mt3'],
	attribution: mbAttr
});

googleStreets = L.tileLayer('http://{s}.google.com/vt?lyrs=m&x={x}&y={y}&z={z}',{
    maxZoom: 20,
    subdomains:['mt0','mt1','mt2','mt3'],
	attribution: mbAttr
});



	var map = L.map('map', {
		center: [<?php echo $locationLat.", ".$locationLon; ?>],	
		zoom: 19,
		layers: [googleStreets,done_h,undone,MyLoc]
	});



	




	var baseLayers = {
		'OpenStreetMap': osm,
		'satellite': googleSat,
		'Streets': googleStreets,
	};

	var overlays = {
		"bins": done_h,
		"bins": undone,
	};

	var layerControl = L.control.layers(baseLayers, overlays).addTo(map);
	




	L.Control.Watermark = L.Control.extend({
		onAdd: function (map) {
			var img = L.DomUtil.create('img');

			img.src = <?php echo json_encode("../".$show_site['logo']); ?> ;
			img.style.width = '200px';

			return img;
		},

		onRemove: function (map) {
			
		}
	});
	L.control.watermark = function (opts) {
		return new L.Control.Watermark(opts);
	};
	
	var watermarkControl = L.control.watermark({position: 'bottomleft'}).addTo(map);


</script>
</div>