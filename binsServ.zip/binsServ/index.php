<?php 
include ("header.php");
?>


<?php 
if(!$_COOKIE[''.md5("binsServ_login").'']){
?>
<form id="filter" class="reg-mobile-active" enctype= "multipart/form-data" method="post" action="">
<div id="logo-inf"><img src='../themes/logoinforep.jpeg' /></div>

<div id="status_form"></div>
<div id="g-phone">
<span class='codecoun'> <i class="fa-solid fa-user"></i> </span> <input  id="username-c" type="text" name="username" placeholder="<?php echo $langs['inp_user']; ?> " required >
</div>
<div id="g-phone">
<span class='codecoun'>966</span> <input  id="mobile-c" type="mobile" name="mobile" placeholder="<?php echo $langs['inp_phone']; ?> " required >
</div>
<p class='note_phone'><?php echo $langs['txt_note_phone']; ?> </p>
<div class="wrapper">
<p><?php echo $langs['get_active_code_by']; ?> : </p>
 <?php /* <input type="radio" value="phone" name="select" id="option-1" >  */?>
 <input type="radio" value="whatsapp" name="select" id="option-2" checked>
 <?php
/*    <label for="option-1" class="option option-1">
     <div class="dot"></div>
      <span> <i class="fa-solid fa-mobile-screen"></i> Phone  </span>
      </label> */?>
   <label for="option-2" class="option option-2">
     <div class="dot"></div>
      <span>  <i class="fa-brands fa-whatsapp"></i> Whatsapp </span>
   </label>
</div>

<button data-html2canvas-ignore="true" name="add" value="OK" type="submit"> <?php echo $langs['btn_next']; ?>  <i class="fa-solid fa-right-long"></i> </button>
</form>


<form id="filter" class="reg-mobile" style="display:none;" enctype= "multipart/form-data" method="post" action="">
<div id="logo-inf"><img src='../themes/logoinforep.jpeg' /></div>
<div id="status_form"></div>
<p id="phone_div">  <?php echo $langs['txt_active_code_sent_to']; ?>: 966 <span></span></p>
<input  type="text" id="activecode"  name="binsServ_activecode" placeholder="<?php echo $langs['inp_active_code']; ?> " required >
<button data-html2canvas-ignore="true" name="add" value="OK" type="submit"> <?php echo $langs['btn_next']; ?>  <i class="fa-solid fa-right-long"></i> </button>
</form>

<script>
let updateloc = setInterval(function(){
	navigator.geolocation.getCurrentPosition(function(location) {
	var latlngg = new L.LatLng(location.coords.latitude, location.coords.longitude);
	$.get("../pages/updatelocation.php?loc="+latlngg+"&acc="+location.coords.accuracy+"");
	},function error(err) {},{enableHighAccuracy:true});
},4000); 
							
							
    $("#filter.reg-mobile-active").submit(function (e) {
        e.preventDefault();
        var fd = new FormData(this);

		$("#filter.reg-mobile-active #status_form").html('<div id="loading" ><span class="loader"></span></div>');
        $.ajax({
                url: 'reg-mobile.php?active=1',
                type: 'POST',
                data: fd,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
					let res = JSON.parse(data);
					if(res.status == true){
						$("#filter.reg-mobile-active").hide();
						$("#filter.reg-mobile").show();
						$("#phone_div span").html($("#mobile-c").val());
					}else{
						$("#filter.reg-mobile-active #status_form").html(res.status);
					}
                },
            }
        );
    });
    $("#filter.reg-mobile").submit(function (e) {
	
        e.preventDefault();
        var fd = new FormData(this);
		$("#filter.reg-mobile #status_form").html('<div id="loading" ><span class="loader"></span></div>');
	
        $.ajax({
                url: 'reg-mobile.php?reg=1',
                type: 'POST',
                data: fd,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
					let resi = JSON.parse(data);
					if(resi.status == true){
	
					    location.reload();
					}else{
						$("#filter.reg-mobile #status_form").html(resi.status);
					}
                },


            }
        );
    });	
</script>

<?php }else{ ?>
<?php 
$q = mysqli_query($con,"select * from binsServ where phone='".$_COOKIE[md5('binsServ_phone')]."' and username='".$_COOKIE[md5('binsServ_username')]."'");
if(mysqli_num_rows($q) == 0){
	exit();
}
$show_user = mysqli_fetch_array($q);

$q_info = mysqli_query($con,"select *,tc_geofences.id as idg from tc_geofences 
				left join tcn_poi_schedule on tc_geofences.id=tcn_poi_schedule.geoid   		
					inner join tcn_routs on tc_geofences.routid = tcn_routs.id 
					inner join tcn_centers on tc_geofences.centerid = tcn_centers.id 
					inner join tcn_bin_type on tc_geofences.bintypeid = tcn_bin_type.id
					where  tc_geofences.id ='".$show_user['idbin']."' order by tcn_poi_schedule.serv_time desc limit 1" );
$show_info = mysqli_fetch_array($q_info);



?>
<div id="info">
<p><?php echo $langs['text_welcome'].", ".$show_user['username']; ?> </p>
<p><?php echo $show_user['phone']; ?> </p>
<p><?php echo $langs['id_container']." : ".$show_info['description']; ?> </p>
<?php echo "<p>".$langs['tb_last_time_empty']."   ".$langs['about']." ".get_time_ago(strtotime($show_info['serv_time']),$langs['year'],$langs['month'],$langs['day'],$langs['hour'],$langs['minute'],$langs['second'])." ".$langs['ago']."</p>"; ?>
<p><a href="logout.php" class="SignOut" class="menuli li-logout sh-load"> <i class="fa-solid fa-right-to-bracket nav_icon"></i>  <span class=" "><?php echo $langs['btn_logout']; ?> </span> </a>	</p>			

</div>
<?php

	$myLocation = explode(",,",map($show_user['location']));

 $locationLat = $myLocation[0];
 $locationLon = $myLocation[1];	
 
/* $locationLat = 27.0961662;
$locationLon = 49.576334;  
 */

  	$q = mysqli_query($con,"select tcn_bin_type.bintype,tcn_routs.rout_code,tcn_poi_schedule.geoid,tcn_poi_schedule.serv_time,tcn_centers.center_name,tc_geofences.description,tc_geofences.area,tc_geofences.id as idg from tc_geofences 
				left join tcn_poi_schedule on tc_geofences.id=tcn_poi_schedule.geoid and  tcn_poi_schedule.serv_time   between  '".$timedate_f."' and '".$timedate_t."'				
					left join tcn_centers on tc_geofences.centerid = tcn_centers.id 
					left join tcn_bin_type on tc_geofences.bintypeid = tcn_bin_type.id
					left join tcn_routs on tc_geofences.routid = tcn_routs.id
					where tc_geofences.type_bins = '0' and JSON_EXTRACT(`tc_geofences`.`attributes`,'$.bins') ='yes'   ");
					
	while($show = mysqli_fetch_assoc($q)){
					$area = explode(",",map($show['area']));

 $distance =  distancepoints($locationLat, $locationLon,$area[0], $area[1]);

	if($distance <= 200){
				if($show['geoid']){
					if($show['idg'] == $show_info['idg']){
				    	$binsel[] ='["<p> '.$langs['tb_route'].' : ' .$show['rout_code'].'</p><p> '.$langs['tb_type'].' : ' .$langs_title[$show['bintype']].'</p><p> '.$langs['container'].' : '.$show['description'].'</p><p> '.$langs['tb_last_time_empty'].' : '.date_css($show['serv_time']).'</p><p>'.$langs['tb_status'].' : <strong> '.$langs['status_empty'].' </strong> </p> <a target=\'_blank\' class=\'openg\' href=\'https://www.google.com/maps/place/'.$area[0].','.$area[1].'\'><i class=\'fa-solid fa-map-location-dot\'></i></a>   </hr />",' .map($show['area']).']';
					}else{
				    	$arr[] ='["<p> '.$langs['tb_route'].' : ' .$show['rout_code'].'</p><p> '.$langs['tb_type'].' : ' .$langs_title[$show['bintype']].'</p><p> '.$langs['container'].' : '.$show['description'].'</p><p> '.$langs['tb_last_time_empty'].' : '.date_css($show['serv_time']).'</p><p>'.$langs['tb_status'].' : <strong> '.$langs['status_empty'].' </strong> </p> <a target=\'_blank\' class=\'openg\' href=\'https://www.google.com/maps/place/'.$area[0].','.$area[1].'\'><i class=\'fa-solid fa-map-location-dot\'></i></a>  <button  class=\'selbin btn_send pgun\' idus=\''.$show_user['id'].' \' selbin=\''.$show['idg'].' \'> '.$langs['sel_bin'].' </button>  </hr />",' .map($show['area']).']';
					}
				}else{
					if($show['idg'] == $show_info['idg']){					
					$binseli[] ='["type='.$langs['tb_route'].' : '.$show['rout_code'].'&infoid=' .$show['idg'].'&desc='.$show['description'].'",' .map($show['area']).']';
				  }else{
					$arri[] ='["type='.$langs['tb_route'].' : '.$show['rout_code'].'&infoid=' .$show['idg'].'&desc='.$show['description'].'",' .map($show['area']).']';
				  }
				}
	}
}

	
if(!isset($arr)){
	$arr[] = '["NAN",0,0]';

} 
if(!isset($arri)){
	$arri[] = '["NAN",0,0]';
 
} 

if(!isset($binsel)){
	$binsel[] = '["NAN",0,0]';

} 
if(!isset($binseli)){
	$binseli[] = '["NAN",0,0]';
 
}					
?>
 <div class='pop_wind seldone' >
<div class='close'>×</div>
<div id="status_data" >
<i class="fa-solid fa-circle-check" style='color:green;margin:0px 5px; 0px'></i> <?php  echo $langs['sel_done_bin']; ?>
</div>
</div>
 <div class='pop_wind selload' >
<div class='close'>×</div>
<div id="status_data" >
<div id="loading" ><span class="loader"></span></div>
</div>
</div>
<div id="map" style="width: 100%; height: 550px;    border: 2px solid #568f31;"></div>

<script>
$(document).ready(function(){
 


var locations = [
<?php echo implode(",",$arr); ?>

];

var locationsi = [
<?php echo implode(",",$arri); ?>

];

var binsel = [
<?php echo implode(",",$binsel); ?>

];

var binseli = [
<?php echo implode(",",$binseli); ?>

];

var startIcon = new L.Icon({
  iconUrl: '../themes/images/icons8-home-page-96.png',
  shadowUrl: '../themes/images/marker-shadow.png',
  iconSize: [35, 35],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});


var binsIcon = new L.Icon({
  iconUrl: '../themes/images/recycle-bin-un.png',
  shadowUrl: '../themes/images/marker-shadow.png',
  iconSize: [33, 33],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

var binsIcon_sel = new L.Icon({
  iconUrl: '../themes/images/recycle-bin-done.png',
  shadowUrl: '../themes/images/marker-shadow.png',
  iconSize: [33, 33],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});


	var selbinMdn = L.layerGroup();
	for (var i = 0; i < binsel.length; i++) {
		marker = new L.marker([binsel[i][1], binsel[i][2]],{icon: binsIcon_sel})
		.bindPopup(binsel[i][0])
		.addTo(selbinMdn);
}	


	var selbinM = L.layerGroup();
	for (var i = 0; i < binseli.length; i++) {
		Binmarkeri = new L.marker([binseli[i][1], binseli[i][2]],{icon: binsIcon_sel});
		Binmarkeri.bindPopup("loading...");
		let urlu = binseli[i][0];
		Binmarkeri.on('click',function(e){
			var popup = e.target.getPopup();
			$.get( "unbin.php?"+urlu+"&idus="+<?php echo $show_user['id']; ?>+"", function( data ) {
						popup.setContent( data );
						popup.update();		
						
 $(".selbin").click(function(){
	let atr = $(this).attr("selbin");
	let idus = $(this).attr("idus");
	let th = $(this);
	th.html("..");	
	$(".selload").show();
	$.get( "selbin.php?id="+atr+"&user="+idus+"", function( data ) {
	th.html(data);
});
});			

						
			});	
			
		});
		Binmarkeri.addTo(selbinM);
}



	var undone = L.layerGroup();
	for (var i = 0; i < locationsi.length; i++) {
		markeri = new L.marker([locationsi[i][1], locationsi[i][2]],{icon: binsIcon});
		markeri.bindPopup("loading...");
		let urlu = locationsi[i][0];
		markeri.on('click',function(e){
			var popup = e.target.getPopup();
			$.get( "unbin.php?"+urlu+"&idus="+<?php echo $show_user['id']; ?>+"", function( data ) {
						popup.setContent( data );
						popup.update();		
						
 $(".selbin").click(function(){
	let atr = $(this).attr("selbin");
	let idus = $(this).attr("idus");
	let th = $(this);
	th.html("..");	
	$(".selload").show();
	$.get( "selbin.php?id="+atr+"&user="+idus+"", function( data ) {
	th.html(data);
});
});			

						
			});	
			
		});
		markeri.addTo(undone);
}


	var done_h = L.layerGroup();
	for (var i = 0; i < locations.length; i++) {
		marker = new L.marker([locations[i][1], locations[i][2]],{icon: binsIcon})
		.bindPopup(locations[i][0])
		.addTo(done_h);
}	

	var MyLoc = L.layerGroup();
		Mymarker = new L.marker([<?php echo $locationLat.", ".$locationLon; ?>],{icon:startIcon})
		.bindPopup(" <i class='fa-solid fa-house'></i> Home")
		.addTo(MyLoc);


	var mbAttr = '&copy; <a href="">almajal</a>';

 
	var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="#">almajal</a>'
	});
	
	googleSat = L.tileLayer('http://{s}.google.com/vt?lyrs=s&x={x}&y={y}&z={z}',{
    maxZoom: 20,
    subdomains:['mt0','mt1','mt2','mt3'],
	attribution: mbAttr
});

googleStreets = L.tileLayer('http://{s}.google.com/vt?lyrs=m&x={x}&y={y}&z={z}',{
    maxZoom: 20,
    subdomains:['mt0','mt1','mt2','mt3'],
	attribution: mbAttr
});



	var map = L.map('map', {
		center: [<?php echo $locationLat.", ".$locationLon; ?>],	
		zoom: 19,
		layers: [googleStreets,done_h,undone,MyLoc,selbinM,selbinMdn]
	});



	




	var baseLayers = {
		'OpenStreetMap': osm,
		'satellite': googleSat,
		'Streets': googleStreets,
	};

	var overlays = {
		"bins": done_h,
		"bins": undone,
	};

	var layerControl = L.control.layers(baseLayers, overlays).addTo(map);
	




	L.Control.Watermark = L.Control.extend({
		onAdd: function (map) {
			var img = L.DomUtil.create('img');

			img.src = <?php echo json_encode("../".$show_site['logo']); ?> ;
			img.style.width = '200px';

			return img;
		},

		onRemove: function (map) {
			
		}
	});
	L.control.watermark = function (opts) {
		return new L.Control.Watermark(opts);
	};
	
	var watermarkControl = L.control.watermark({position: 'bottomleft'}).addTo(map);
	

map.on('popupopen', function() {  
 $(".selbin").click(function(){
	let atr = $(this).attr("selbin");
	let idus = $(this).attr("idus");
	let th = $(this);
	th.html("..");	
	$(".selload").show();	
	$.get( "selbin.php?id="+atr+"&user="+idus+"", function( data ) {
	th.html(data);
});
});	
});

});
</script>




<?php } ?>
</div>
</div>




</body>
</html>

<?php 
ob_end_flush();
?>
