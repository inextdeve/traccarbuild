<?php 
  include "../config.php";
 if($_GET['id']){
 
			 
			$q = mysqli_query($con,"update binsServ set idbin='".$_GET['id']."' where id='".$_GET['user']."'"); 
			 if($q){
				 echo $langs['sel_done_bin'];
				 ?>
	
<script>
$(".selload").hide();
$(".seldone").show();
location.reload();
</script>			 
				 <?php

			 }
 
 }  
?>