<?php include("../config.php"); ?>
<!doctype html>
<html> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

 		<link rel="icon" href="../themes/favicon.ico">
<title><?php echo $show_site['name']; ?></title>
	<script src="../themes/<?php echo $show_site['theme'] ?>/tbsw/tablesaw.js"></script>
	<script src="../themes/<?php echo $show_site['theme'] ?>/tbsw/tablesaw-init.js"></script>

<script type="text/javascript" src="../themes/jquery-3.6.1.min.js"></script>
  <script type="text/javascript" src="../themes/jquery-ui.min.js"></script>
  <script src="../themes/<?php echo $show_site['theme'] ?>/themes.js" ></script>

  <link rel="stylesheet" href="../themes/almj_style_v.php?css">
  <link rel="stylesheet" href="../themes/<?php echo $show_site['theme'] ?>/themes.css">
<?php 
if($lang_dir == "rtl"){
echo '<link rel="stylesheet" href="../themes/'.$show_site['theme'].'/themes_ar.css">';
}
?>


<link rel="stylesheet" href="../themes/jquery-ui.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../themes/leaflet.css" />
    <script src="../themes/leaflet.js" ></script>
<link rel="stylesheet" href="../themes/leaflet-routing-machine.css" />	
<script src="../themes/leaflet-routing-machine.js"></script>
<script src='../themes/<?php echo $show_site['theme'] ?>/sorts/tablesort.js'></script>
<script src='../themes/<?php echo $show_site['theme'] ?>/sorts/tablesort.number.js'></script>
<script src='../themes/<?php echo $show_site['theme'] ?>/sorts/tablesort.date.js'></script>
<link rel="stylesheet" href='../themes/<?php echo $show_site['theme'] ?>/sorts/tablesort.css' /> 

	<link rel="stylesheet" href="../themes/<?php echo $show_site['theme'] ?>/tbsw/tablesaw.css">


  <link rel="stylesheet" href="binsServ.css">

</head>
<body>

<div id="content-bd">
<nav>

<div class="nav-side"> 
 <div class="dropdown">
    <button class="dropbtn"><?php echo $langs['language']; ?>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
<?php 
$q_men = mysqli_query($con,"select * from ".$dbname.".tcn_lang");
while($sh_m_l = mysqli_fetch_array($q_men)){
	echo '<a  class="dropdown-item" href="../sellang.php?lang='.$sh_m_l['lang'].'&'.$_SERVER['QUERY_STRING'].'&binsServ=binsServ&auto='.$auto.'">'.$sh_m_l['lang'].'  </a>';
}
?>
    </div>
  </div>
  


    </div>

<div class="nav-side"> 
 <div class="logo-nav"> <img src="../<?php echo $show_site['logo']; ?>" alt=""> </div>
 </div>	
</nav>
<div id="content-pg">
<div id="content-div">
<div id="loading" class="loadingpg" style="display:none;"><span class="loader"></span></div>
<?php 
$time_f = $show_site['start_day'];	
$time_t = $show_site['end_day'];	
$date_f =  date("Y-m-d");
$date_t =  date("Y-m-d");

	$timedate_f = $date_f." ".$time_f;
	$timedate_t = $date_t." ".$time_t;
?>