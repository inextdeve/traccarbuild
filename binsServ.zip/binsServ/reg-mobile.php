<?php 
  include    "../tel/vendor/autoload.php";
  use telesign\sdk\messaging\MessagingClient;
  include("../config.php");

if(isset($_GET['active'])){
$mobile = "966".intval($_POST['mobile']);
$username = htmlspecialchars($_POST['username']);
if(isset($_POST['username']) and isset($_POST['mobile']) and strlen($_POST['mobile']) > 4){ 
$activeCode = rand(00000,99999);
/* 	
if($_POST['select'] == "phone"){

  $customer_id = "B38ACCD0-E178-42E6-820D-717FA8A218E9";
  $api_key = "H1IV1unGMN9yf4fXXxxHk6uK+pJmfxY9EA4b4GhLsRUPdOP60xNC9ySx06Nio6ml/uERo0NWw0zuS4NLQAPEFw==";
  $message = "رمز التفعيل هو : ".$activeCode."";
  $message_type = "OTP";
  $messaging = new MessagingClient($customer_id, $api_key);
  $response = $messaging->message($mobile, $message, $message_type);

   if($response->status_code == "200"){
	setcookie(''.md5("binsServ_activecode").'',''.md5($activeCode).'', time() + (60 * 4), "/"); 
		$_SESSION['binsServ_phone_ac'] = $mobile;
		$_SESSION['binsServ_username'] = $username;
		
	echo json_encode(["status"=>true],JSON_UNESCAPED_UNICODE );		

   }else{
			echo json_encode(["status"=>"<p class='err_notif'>".$langs['notice_error']."</p>"],JSON_UNESCAPED_UNICODE ); 	
 
   }
 
}
	 */  
if($_POST['select'] == "whatsapp"){
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://wacode.app/api/create-message',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array(
  'appkey' => '30716d9c-fcab-4ea1-87ed-028b2a632b67',
  'authkey' => 'KtqDYNjNL5QeUO0o9uaqaiYiPEFwPqNfM98ukxZGUdyYty5Wz3',
  'to' => $mobile,
  'message' => "رمز التفعيل هو : ".$activeCode,
  'sandbox' => 'false'
  ),
    CURLOPT_HTTPHEADER => array(
    "content-type" => "application/x-www-form-urlencoded"
  ),    
));


 $response = json_decode(curl_exec($curl),true);

$err = curl_error($curl);
curl_close($curl);

if ($err) {
 // echo "cURL Error #:" . $err;
} else {
  if($response['message_status'] == 'Success'){
	setcookie(''.md5("binsServ_activecode").'',''.md5($activeCode).'', time() + (60 * 4), "/"); 
	$_SESSION['binsServ_phone_ac'] = $mobile;
	$_SESSION['binsServ_username'] = $username;
	
	echo json_encode(["status"=>true],JSON_UNESCAPED_UNICODE );		
  }else{
			echo json_encode(["status"=>"<p class='err_notif'>".$langs['notice_empty']."</p>"],JSON_UNESCAPED_UNICODE ); 	
  }
}
	
}	
}else{
			echo json_encode(["status"=>"<p class='err_notif'>".$langs['notice_empty']."</p>"],JSON_UNESCAPED_UNICODE ); 	
}	
}


if(isset($_GET['reg'])){
if(md5($_POST['binsServ_activecode']) == $_COOKIE[''.md5('binsServ_activecode').'']){

$q = mysqli_query($con,"select * from binsServ where phone='".$_SESSION['binsServ_phone_ac']."' ");
$show_user = mysqli_fetch_array($q);
if(mysqli_num_rows($q) == 0){
		$q = mysqli_query($con,"insert into binsServ (`phone`,`username`,`location`) values('".$_SESSION['binsServ_phone_ac']."','".$_SESSION['binsServ_username']."','".$_SESSION['locationmobile_user']."')");
		if($q){
	setcookie(''.md5("binsServ_login").'',''.$_COOKIE[''.md5('binsServ_activecode').''].'', time() + (86400  * 60), "/"); 
	setcookie(''.md5("binsServ_phone").'',''.$_SESSION['binsServ_phone_ac'].'', time() + (86400  * 60), "/"); 
	setcookie(''.md5("binsServ_username").'',''.$_SESSION['binsServ_username'].'', time() + (86400  * 60), "/"); 		
	echo json_encode(["status"=>true],JSON_UNESCAPED_UNICODE );
	
}
}else{
	$q = mysqli_query($con,"update binsServ set location='".$_SESSION['locationmobile_user']."' where id ='".$show_user['id']."' ");
	setcookie(''.md5("binsServ_login").'',''.$_COOKIE[''.md5('binsServ_activecode').''].'', time() + (86400  * 60), "/"); 
	setcookie(''.md5("binsServ_phone").'',''.$_SESSION['binsServ_phone_ac'].'', time() + (86400  * 60), "/"); 
	setcookie(''.md5("binsServ_username").'',''.$show_user['username'].'', time() + (86400  * 60), "/"); 		
	echo json_encode(["status"=>true],JSON_UNESCAPED_UNICODE );	
}
		
}else{
			echo json_encode(["status"=>"<p class='err_notif'>".$langs['notice_error']."</p>"],JSON_UNESCAPED_UNICODE ); 	

}	
}












?>
