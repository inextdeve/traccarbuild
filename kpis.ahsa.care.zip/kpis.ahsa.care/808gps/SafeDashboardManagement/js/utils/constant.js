const streamURL = "http://v.rcj.care";

export { streamURL };
